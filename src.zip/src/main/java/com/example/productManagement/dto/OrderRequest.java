package com.example.productManagement.dto;

import lombok.Data;

@Data
public class OrderRequest {
	
	private Long userId;
	private Long addressId;

}
