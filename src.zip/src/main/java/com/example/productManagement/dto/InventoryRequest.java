package com.example.productManagement.dto;

import lombok.Data;

@Data
public class InventoryRequest {
	
	private Integer quantity;
	
	private Long productId;

}
