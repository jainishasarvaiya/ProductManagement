package com.example.productManagement.dto;

import lombok.Data;

@Data
public class CartRequest {
	
	private Integer quantity;
	private Long productId;

}
