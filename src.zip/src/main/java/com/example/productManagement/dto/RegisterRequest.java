package com.example.productManagement.dto;

import com.example.productManagement.enums.Role;

import lombok.Data;

@Data
public class RegisterRequest {
	
	private String username;
	private String email;
	private String password;
	
	private Role role;

}
