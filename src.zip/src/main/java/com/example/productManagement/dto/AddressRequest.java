package com.example.productManagement.dto;

import lombok.Data;

@Data
public class AddressRequest {
	
	private String houseNo;
	private String street;
	private String city;
	private String state;
	private String pincode;

	private Long userId;
}
