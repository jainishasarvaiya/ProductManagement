package com.example.productManagement.dto;

import lombok.Data;

@Data
public class ProductRequest {
	
	private String name;
	private String description;
	private Integer price;
	private boolean enabled;
	
	private Long categoryId;

}
