package com.example.productManagement.dto;

import lombok.Data;

@Data
public class CategoryRequest {
	
	private String name;
	private String description;


}
