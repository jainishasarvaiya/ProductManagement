package com.example.productManagement.enums;

public enum Role {
	
	USER,
	ADMIN,
	SUPER_ADMIN

}
