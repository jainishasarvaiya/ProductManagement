package com.example.productManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productManagement.dto.InventoryRequest;
import com.example.productManagement.entity.InventoryEntity;
import com.example.productManagement.service.InventoryService;

@RestController
@RequestMapping("/inventory")
public class InaventoryController {
	
	@Autowired
	private InventoryService inventoryService;
	
	@GetMapping
	public List<InventoryEntity> getAllInventory(){
		return inventoryService.getAllInventory();
	}
	
	@GetMapping("/{id}")
	public InventoryEntity getInventoryById(@PathVariable Long id) {
		return inventoryService.getInventoryById(id);
	}
	
	@PostMapping("/add")
	public InventoryEntity addInventory(@RequestBody InventoryRequest request) {
		return inventoryService.addInventory(request);
	}
	
	@PutMapping("/update")
	public InventoryEntity updateInventory(@PathVariable Long id, InventoryRequest request) {
		return inventoryService.updateInventory(id, request);
	}
	
	@DeleteMapping("/delete")
	public String deleteInventory(@PathVariable Long id) {
		 inventoryService.deleteInventory(id);
		 return "Inventory deleted succesfully";
	}
	

}
