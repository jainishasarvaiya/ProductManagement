package com.example.productManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productManagement.dto.AddressRequest;
import com.example.productManagement.entity.AddressEntity;
import com.example.productManagement.service.AddressService;

@RestController
@RequestMapping("/address")
public class AddressController {
	
	@Autowired
	private AddressService addressService;
	
	@GetMapping
	public List<AddressEntity> getAllAddresses(){
		return addressService.getAllAddresses();
	}
	
	@GetMapping("/{id}")
	public AddressEntity getAddressById(@PathVariable Long id) {
		return addressService.getAddressById(id);
	}
	
	@PostMapping("/add")
	public AddressEntity AddAddress(@RequestBody AddressRequest request) {
		return addressService.addAddress(request);
	}
	
	@PutMapping("/update")
	public AddressEntity updateAddress(@PathVariable Long id, @RequestBody AddressRequest request) {
		return addressService.updateAddress(id, request);
	}
	
	@DeleteMapping("/delete")
	public String deleteAddress(@PathVariable Long id) {
		addressService.deleteAddress(id);
		return "Address Deleted successfully";
	}

}
