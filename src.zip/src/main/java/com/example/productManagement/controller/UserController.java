package com.example.productManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productManagement.dto.LoginRequest;
import com.example.productManagement.dto.RegisterRequest;
import com.example.productManagement.entity.UserEntity;
import com.example.productManagement.service.UserService;

@RestController
@RequestMapping("/users")
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@GetMapping
	public List<UserEntity> getAllUser(){
		return userService.getAllUser();
	}
	
	@GetMapping("/{id}")
	public UserEntity getUserById(@PathVariable Long id) {
		return userService.getUserById(id);
	}
	
	@PostMapping("/register")
	public UserEntity register(@RequestBody RegisterRequest request) {
		return userService.register(request);
	}
	
	@PostMapping("/login")
	public UserEntity login(@RequestBody LoginRequest request) {
		return userService.login(request);
	}
	
	@PutMapping("/update")
	public UserEntity updateUser( @PathVariable Long id, @RequestBody RegisterRequest request) {
		return userService.updateUser(id, request);
	}

}
