package com.example.productManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productManagement.dto.ProductRequest;
import com.example.productManagement.entity.ProductEntity;
import com.example.productManagement.service.ProductService;

@RestController
@RequestMapping("/product")
public class ProductController {
	
	@Autowired
	private ProductService productService;
	
	@GetMapping
	public List<ProductEntity> getAllProduct(){
		return productService.getAllProduct();
	}
	
	@GetMapping("/{id}")
	public ProductEntity getProductById(@PathVariable Long id) {
		return productService.getProductById(id);
	}
	
	@PostMapping("/add")
	public ProductEntity addProduct(@RequestBody ProductRequest request) {
		return productService.addProduct(request);
	}
	
	@PutMapping("/update")
	public ProductEntity updateProduct(@PathVariable Long id, @RequestBody ProductRequest request) {
		return productService.updateProduct(id, request);
	}
	
	@DeleteMapping("/delete")
	public String deleteProduct(@PathVariable Long id) {
		 productService.deleteProduct(id);
		 return "product Deleted successfully";
	}

}
