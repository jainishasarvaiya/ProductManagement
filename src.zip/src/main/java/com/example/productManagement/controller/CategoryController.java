package com.example.productManagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.productManagement.dto.CategoryRequest;
import com.example.productManagement.entity.CategoryEntity;
import com.example.productManagement.service.CategoryService;

@RestController
@RequestMapping("/category")
public class CategoryController {
	
	@Autowired
	private CategoryService categoryService;
	
	@GetMapping
	public List<CategoryEntity> getAllCategory(){
		return categoryService.getAllCategories();
	}
	
	@GetMapping("/{id}")
	public CategoryEntity getCategoryById(@PathVariable Long id) {
		return categoryService.getCategoryById(id);
	}
	
	@PostMapping("/add")
	public CategoryEntity addCategory(@RequestBody CategoryRequest request) {
		return categoryService.addCategory(request);
	}
	
	@PutMapping("/update")
	public CategoryEntity updateCategory(@PathVariable Long id, @RequestBody CategoryRequest request) {
		return categoryService.updateCategory(id, request);
	}
	
	@DeleteMapping("/delete")
	public String deleteCategory(@PathVariable Long id) {
		categoryService.deleteCategory(id);
		return "category Deleted Successfully";
	}

}
