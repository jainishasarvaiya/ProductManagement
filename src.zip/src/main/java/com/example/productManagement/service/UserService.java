package com.example.productManagement.service;

import java.util.List;

import com.example.productManagement.dto.LoginRequest;
import com.example.productManagement.dto.RegisterRequest;
import com.example.productManagement.entity.UserEntity;

public interface UserService {

	List<UserEntity> getAllUser();

	UserEntity getUserById(Long id);

	UserEntity register(RegisterRequest request);

	UserEntity updateUser(Long id, RegisterRequest request);

	UserEntity login(LoginRequest request);

}
