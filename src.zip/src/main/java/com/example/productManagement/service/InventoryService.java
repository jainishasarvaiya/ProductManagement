package com.example.productManagement.service;

import java.util.List;

import com.example.productManagement.dto.InventoryRequest;
import com.example.productManagement.entity.InventoryEntity;

public interface InventoryService {

	List<InventoryEntity> getAllInventory();

	InventoryEntity getInventoryById(Long id);

	InventoryEntity addInventory(InventoryRequest request);

	InventoryEntity updateInventory(Long id, InventoryRequest request);

	String deleteInventory(Long id);

}
