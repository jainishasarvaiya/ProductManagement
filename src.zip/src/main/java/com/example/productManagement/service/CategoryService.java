package com.example.productManagement.service;

import java.util.List;

import com.example.productManagement.dto.CategoryRequest;
import com.example.productManagement.entity.CategoryEntity;

public interface CategoryService {

	List<CategoryEntity> getAllCategories();

	CategoryEntity getCategoryById(Long id);

	CategoryEntity addCategory(CategoryRequest request);

	CategoryEntity updateCategory(Long id, CategoryRequest request);

	String deleteCategory(Long id);

}
