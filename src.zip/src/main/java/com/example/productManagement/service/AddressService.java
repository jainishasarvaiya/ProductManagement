package com.example.productManagement.service;

import java.util.List;

import com.example.productManagement.dto.AddressRequest;
import com.example.productManagement.entity.AddressEntity;

public interface AddressService {

	List<AddressEntity> getAllAddresses();

	AddressEntity getAddressById(Long id);

	AddressEntity addAddress(AddressRequest request);

	AddressEntity updateAddress(Long id, AddressRequest request);

	String deleteAddress(Long id);

}
