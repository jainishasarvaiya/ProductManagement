package com.example.productManagement.service;

public interface OrderService {

}
