package com.example.productManagement.service;

public interface CartService {

}
