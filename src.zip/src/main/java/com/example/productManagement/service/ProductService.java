package com.example.productManagement.service;

import java.util.List;

import com.example.productManagement.dto.ProductRequest;
import com.example.productManagement.entity.ProductEntity;

public interface ProductService {

	List<ProductEntity> getAllProduct();
	
    ProductEntity getProductById(Long id);
    
    ProductEntity addProduct(ProductRequest request);

	ProductEntity updateProduct(Long id, ProductRequest request);

	String deleteProduct(Long id);;
}
