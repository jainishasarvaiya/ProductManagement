package com.example.productManagement.serviceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.repository.CartItemRepository;
import com.example.productManagement.repository.CartRepository;
import com.example.productManagement.repository.ProductRepository;
import com.example.productManagement.repository.UserRepository;
import com.example.productManagement.service.CartService;

@Service
public class CartServiceImpl implements CartService{
	
	@Autowired
	private CartRepository cartRepository;
	
	@Autowired
	private CartItemRepository cartItemRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private UserRepository userRepository;

}
