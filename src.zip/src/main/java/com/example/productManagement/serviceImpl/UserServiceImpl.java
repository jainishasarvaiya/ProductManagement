package com.example.productManagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.dto.LoginRequest;
import com.example.productManagement.dto.RegisterRequest;
import com.example.productManagement.entity.UserEntity;
import com.example.productManagement.enums.Role;
import com.example.productManagement.repository.UserRepository;
import com.example.productManagement.service.UserService;

@Service
public class UserServiceImpl implements UserService{
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<UserEntity> getAllUser(){
		return userRepository.findAll();
	}
	
	@Override
	public UserEntity getUserById(Long id) {
		return userRepository.findById(id).orElseThrow(() -> new RuntimeException("user not found"));
	}
	
	@Override
	public UserEntity register(RegisterRequest request) {
		UserEntity user = new UserEntity();
		
		user.setEmail(request.getEmail());
		user.setUsername(request.getUsername());
		user.setPassword(request.getPassword());
		user.setRole(request.getRole() !=null ? request.getRole() : Role.USER);
		
		return userRepository.save(user);
	}
	
	@Override
	public UserEntity updateUser(Long id, RegisterRequest request) {
		UserEntity user = userRepository.findById(id).orElseThrow(()-> new RuntimeException("user not found"));
		
		user.setEmail(request.getEmail());
		user.setUsername(request.getUsername());
		user.setPassword(request.getPassword());
		
		return userRepository.save(user);
	}
	
	@Override
	public UserEntity login(LoginRequest request) {
		UserEntity user = userRepository.findByUsername(request.getUsername()).orElseThrow(()-> new RuntimeException("user not found"));
		
		if(!user.getPassword().equals(request.getPassword())) {
			throw new RuntimeException("Invalid Password");
		}
		return user;
	}

}
