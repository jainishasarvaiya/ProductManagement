package com.example.productManagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.dto.CategoryRequest;
import com.example.productManagement.entity.CategoryEntity;
import com.example.productManagement.repository.CategoryRepository;
import com.example.productManagement.service.CategoryService;

@Service
public class CategoryServiceImpl implements CategoryService{
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Override
	public List<CategoryEntity> getAllCategories(){
		return categoryRepository.findAll();
	}
	
	@Override
	public CategoryEntity getCategoryById(Long id) {
		return categoryRepository.findById(id).orElseThrow(()-> new RuntimeException());
	}
	
	@Override
	public CategoryEntity addCategory(CategoryRequest request) {
		CategoryEntity category = new CategoryEntity();
		category.setName(request.getName());
		category.setDescripton(request.getDescription());
		
		return categoryRepository.save(category);
	}
	
	@Override
	public CategoryEntity updateCategory(Long id, CategoryRequest request) {
		CategoryEntity category = categoryRepository.findById(id).orElseThrow(()-> new RuntimeException("category not found"));
		
		category.setName(request.getName());
		category.setDescripton(request.getDescription());
		
		return categoryRepository.save(category);
	}
	
	@Override
	public String deleteCategory(Long id) {
		CategoryEntity category = categoryRepository.findById(id).orElseThrow(()-> new RuntimeException("category not found"));
		
		categoryRepository.delete(category);
		return "Category deleted successfully";
	}

}
