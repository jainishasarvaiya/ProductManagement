package com.example.productManagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.dto.AddressRequest;
import com.example.productManagement.entity.AddressEntity;
import com.example.productManagement.entity.UserEntity;
import com.example.productManagement.repository.AddressRepository;
import com.example.productManagement.repository.UserRepository;
import com.example.productManagement.service.AddressService;

@Service
public class AddressServiceImpl implements AddressService{
	
	@Autowired
	private AddressRepository addressRepository;
	
	@Autowired
	private UserRepository userRepository;
	
	@Override
	public List<AddressEntity> getAllAddresses(){
		return addressRepository.findAll();
	}
	
	@Override
	public AddressEntity getAddressById(Long id) {
		return addressRepository.findById(id).orElseThrow(()-> new RuntimeException("address not found"));
	}
	
	@Override
	public AddressEntity addAddress(AddressRequest request) {
		UserEntity user = userRepository.findById(request.getUserId()).orElseThrow(()-> new RuntimeException("user not found"));
		
		AddressEntity address = new AddressEntity();
		address.setHouseNo(request.getHouseNo());
		address.setStreet(request.getStreet());
		address.setCity(request.getCity());
		address.setState(request.getState());
		address.setPincode(request.getPincode());
		address.setUser(user);
		
		return addressRepository.save(address);
		
	}
	
	@Override
	public AddressEntity updateAddress(Long id, AddressRequest request) {
		AddressEntity address = addressRepository.findById(id).orElseThrow(()-> new RuntimeException("address not found"));
		address.setHouseNo(request.getHouseNo());
		address.setStreet(request.getStreet());
		address.setCity(request.getCity());
		address.setState(request.getState());
		address.setPincode(request.getPincode());
		
		return addressRepository.save(address);
	}
	
	@Override
	public String deleteAddress(Long id) {
		AddressEntity address = addressRepository.findById(id).orElseThrow(()-> new RuntimeException("address not found"));
		addressRepository.delete(address);
		return "address deletes successfully";
	}

}
