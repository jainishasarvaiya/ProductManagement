package com.example.productManagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.dto.ProductRequest;
import com.example.productManagement.entity.CategoryEntity;
import com.example.productManagement.entity.ProductEntity;
import com.example.productManagement.repository.CategoryRepository;
import com.example.productManagement.repository.ProductRepository;
import com.example.productManagement.service.ProductService;

@Service
public class ProductServiceImpl implements ProductService{
	
	@Autowired
	private ProductRepository productRepository;
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	
	@Override
	public List<ProductEntity> getAllProduct(){
		return productRepository.findAll();
	}

	@Override
	public ProductEntity getProductById(Long id) {
		return productRepository.findById(id).orElseThrow(()-> new RuntimeException("product not found"));
	}

	@Override
	public ProductEntity addProduct(ProductRequest request) {
		CategoryEntity category = categoryRepository.findById(request.getCategoryId()).orElseThrow(()-> new RuntimeException("category not found"));
		
		ProductEntity product = new ProductEntity();
		
		product.setName(request.getName());
		product.setDescription(request.getDescription());
		product.setPrice(request.getPrice());
		product.setEnabled(request.isEnabled());
		product.setCategory(category);
		
		return productRepository.save(product);
	}
	
	@Override
	public ProductEntity updateProduct(Long id, ProductRequest request) {
		CategoryEntity category = categoryRepository.findById(request.getCategoryId()).orElseThrow(()-> new RuntimeException("category not found"));
		
		ProductEntity product = productRepository.findById(id).orElseThrow(()-> new RuntimeException("product not found"));
		
		product.setName(request.getName());
		product.setDescription(request.getDescription());
		product.setPrice(request.getPrice());
		product.setEnabled(request.isEnabled());
		product.setCategory(category);
		
		return productRepository.save(product);
	}
	
	@Override
	public String deleteProduct(Long id) {
		ProductEntity product = productRepository.findById(id).orElseThrow(()-> new RuntimeException("product not found"));
		productRepository.delete(product);
		
		return "product deleted successfully";
	}
	
	
	

}
