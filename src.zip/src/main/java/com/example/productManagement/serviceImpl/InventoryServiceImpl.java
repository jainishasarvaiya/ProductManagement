package com.example.productManagement.serviceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.productManagement.dto.InventoryRequest;
import com.example.productManagement.entity.InventoryEntity;
import com.example.productManagement.entity.ProductEntity;
import com.example.productManagement.repository.InventoryRepository;
import com.example.productManagement.repository.ProductRepository;
import com.example.productManagement.service.InventoryService;

@Service
public class InventoryServiceImpl implements InventoryService{
	
	@Autowired
	private InventoryRepository inventoryRepository;
	
	@Autowired
	private ProductRepository productRepository;
	
	@Override
	public List<InventoryEntity> getAllInventory(){
		return inventoryRepository.findAll();
	}
	
	@Override
	public InventoryEntity getInventoryById(Long id) {
		return inventoryRepository.findById(id).orElseThrow(()-> new RuntimeException("inventory not found"));
	}
	
	@Override
	public InventoryEntity addInventory(InventoryRequest request) {
		ProductEntity product = productRepository.findById(request.getProductId()).orElseThrow(()-> new RuntimeException("product not found"));
		
		if (inventoryRepository.findByProductId(request.getProductId())
                .isPresent()) {
            throw new RuntimeException(
                    "Inventory already exists for this product");
        }
		
		InventoryEntity inventory = new InventoryEntity();
		inventory.setQuantity(request.getQuantity());
		inventory.setProduct(product);
		
		return inventoryRepository.save(inventory);
	}
	
	@Override
	public InventoryEntity updateInventory(Long id, InventoryRequest request) {
		InventoryEntity inventory = inventoryRepository.findById(id).orElseThrow(()-> new RuntimeException("Inventory ot found"));
		inventory.setQuantity(request.getQuantity());
		
		return inventoryRepository.save(inventory);
	}
	
	@Override
	public String deleteInventory(Long id) {
		InventoryEntity inventory = inventoryRepository.findById(id).orElseThrow(()-> new RuntimeException("Inventory ot found"));
		
		inventoryRepository.delete(inventory);
		return "Inventory deleted successfully";
	}
	
	
	
	

}
