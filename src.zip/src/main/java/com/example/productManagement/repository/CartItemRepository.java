package com.example.productManagement.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.productManagement.entity.CartItemEntity;

@Repository
public interface CartItemRepository extends JpaRepository<CartItemEntity, Long>{

	Optional<CartItemEntity> findByCartIdAndProductId(Long cartId, Long productId);
	
	List<CartItemEntity> findByCartId(Long cartId);
	
}
