package com.example.productManagement.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import lombok.Data;

@Entity
@Data
public class OrderItemEntity {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	private Integer quantity;
	private double price;
	
	@ManyToOne
	@JoinColumn(name = "oder_id")
	private OrderEntity order;
	
	@ManyToOne
	@JoinColumn(name = "product_id")
	private ProductEntity product;

}
